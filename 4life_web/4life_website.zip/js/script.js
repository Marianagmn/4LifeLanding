// Scroll suave entre secciones
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const destino = document.querySelector(this.getAttribute('href'));
    if (destino) {
      e.preventDefault();
      destino.scrollIntoView({ behavior: 'smooth' });
    }
  });
});

// Botón "Volver arriba"
const btnTop = document.getElementById("btnTop");
if (btnTop) {
  window.addEventListener("scroll", () => {
    btnTop.classList.toggle("show", window.scrollY > 400);
  });
  btnTop.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
}

// Animaciones al hacer scroll (productos, nosotros)
const animatedItems = document.querySelectorAll('.product-card, #nosotros img');
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate__animated', 'animate__fadeInUp');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  animatedItems.forEach(item => observer.observe(item));
} else {
  // fallback: add classes immediately
  animatedItems.forEach(item => item.classList.add('animate__animated', 'animate__fadeInUp'));
}
